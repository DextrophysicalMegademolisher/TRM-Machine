-- Coding by skidhi
-- SFX by skidhi and cellua

-- DONT YOU DARE STEAL THIS CODE!!!!!! i dont think anyone will tho.....
local timer, selectedCell, selectedRot, rotatetimer, selectCellTimer = 0, 2, 0, 0, 0
local cells, gridX, gridY = {}, 50, 50
local halfpi, tex, cellSize = math.pi/2, {}, nil
local camX, camY, originX, originY = gridX/2, gridY/2, nil, nil
local moverTypes = {2}

-- Load textures
function NewTexture(name, key)
    tex[key] = love.graphics.newImage("textures/"..name..".png")
end

NewTexture("empty", 0)
NewTexture("wall", 1)
NewTexture("mover", 2)
NewTexture("pushable", 3)

cellSize = 32/tex[0]:getWidth()
originX = tex[1]:getWidth() / 2
originY = tex[1]:getHeight() / 2

function DeleteCell(idx)
    table.remove(cells, idx)
end

function lerp(s, e, t)
    return s + (e - s) * t
end

function DrawCell(tex, x, y, dir)
    local cellX = (x-1)*32-camX
    local cellY = (y-1)*32+camY
    DrawBasic(tex, cellX, cellY, dir)
end

function DrawBasic(tex, x, y, dir)
    love.graphics.draw(tex, x, y, dir*halfpi, cellSize, cellSize, originX, originY)
end

function DrawBGCells()
    for x = 1, gridX do
        for y = 1, gridY do
            DrawCell(tex[0], x, y, 0)
        end
    end
end

function DrawGridCells()
    for _,c in ipairs(cells) do
        DrawCell(tex[c.type], lerp(c.x, c.nx, timer), lerp(c.y, c.ny, timer), c.dir)    
    end
end

function PlaceCell(type, x, y, dir)
    if x > 0 and x < gridX + 1 and y > 0 and y < gridY + 1 then
        cells[#cells+1] = {type = type, x = x, y = y, dir = dir, nx = x, ny = y}
    end
end

function DrawHoverCell(tex, x, y, dir)
    love.graphics.setColor(1, 1, 1, 0.5)
    DrawCell(tex, x, y, dir)
    love.graphics.setColor(1, 1, 1, 1)
end

function PushCell(x, y, idx, dir)
    local cx = 0
    local cy = 0

    if dir == 0 then cx = cx + 1 end
    if dir == 1 then cy = cy + 1 end
    if dir == 2 then cx = cx - 1 end
    if dir == 3 then cy = cy - 1 end

    if cells[idx].type == 1 then
        force = 0
        return
    end

    if GetID(x + cx, y + cy) then
        if contains(moverTypes, cells[GetID(x + cx, y + cy)].type) then
            if dir == (cells[GetID(x + cx, y + cy)].dir + 2)%4 then
                force = force - 1
            end
            if dir == cells[GetID(x + cx, y + cy)].dir then
                force = force + 1
            end
        end
    end

    if force > 0 then
        if GetID(x + cx, y + cy) then
            PushCell(x + cx, y + cy, GetID(x + cx, y + cy), dir)
        end
    end

    if force > 0 then
        cells[idx].nx = x + cx
        cells[idx].ny = y + cy
    end
end

function contains(list, value)
    for _, v in ipairs(list) do
        if v == value then
            return true
        end
    end
    return false
end

function GetID(x, y)
    for i,c in ipairs(cells) do
        if c.nx == x then
            if c.ny == y then
                return i
            end
        end   
    end
    return nil
end

function updateCell(id, dir)
    for i,c in ipairs(cells) do
        if c.type == id then
            if id == 2 then
                if c.dir == dir then
                    force = 1
                    PushCell(c.nx, c.ny, i, c.dir)
                end
            end
        end   
    end
end

function resetCells()
    for _,c in ipairs(cells) do
        c.x = c.nx
        c.y = c.ny
    end
end

function love.draw()
    DrawBGCells()
    DrawGridCells()
    DrawHoverCell(tex[selectedCell], mouseGridX, mouseGridY, selectedRot)
end

function love.update(dt)
    timer = timer + 0.1

    if timer > 1 then
        timer = 0
        resetCells()
        updateCell(2, 0)
        updateCell(2, 2)
        updateCell(2, 3)
        updateCell(2, 1)
    end

    -- Update camera
    if love.keyboard.isDown("w") then camY = camY + 5 end
    if love.keyboard.isDown("s") then camY = camY - 5 end
    if love.keyboard.isDown("a") then camX = camX - 5 end
    if love.keyboard.isDown("d") then camX = camX + 5 end

    -- Turning the selected cell
    if rotatetimer > 0 then
        rotatetimer = rotatetimer + 0.1
    end

    if rotatetimer == 0 then
        if love.keyboard.isDown("e") then 
            selectedRot = (selectedRot + 1)%4
            rotatetimer = rotatetimer + 0.1
        end
    end

    if rotatetimer == 0 then
        if love.keyboard.isDown("q") then 
            selectedRot = (selectedRot - 1)%4
            rotatetimer = rotatetimer + 0.1
        end
    end

    -- Changing the selected cell
    if rotatetimer >= 1 then
        rotatetimer = 0
    end

    if selectCellTimer > 0 then
        selectCellTimer = selectCellTimer + 0.1
    end

    if selectCellTimer == 0 then
        if love.keyboard.isDown("2") then 
            if selectedCell < #tex then
                selectedCell = selectedCell + 1
                selectCellTimer = selectCellTimer + 0.1
            end
        end
    end

    if selectCellTimer == 0 then
        if love.keyboard.isDown("1") then
            if selectedCell > 1 then 
                selectedCell = selectedCell - 1
                selectCellTimer = selectCellTimer + 0.1
            end
        end
    end

    if selectCellTimer >= 1 then
        selectCellTimer = 0
    end

    -- Placing cells
    mouseX, mouseY = love.mouse.getPosition()
    mouseGridX = math.floor((mouseX+camX)/32)+1
    mouseGridY = math.floor((mouseY-camY)/32)+1

    if love.mouse.isDown(1) then
        if mouseGridX > 1 and mouseGridX < gridX and mouseGridY > 1 and mouseGridY < gridY then
            if GetID(mouseGridX, mouseGridY) then
                DeleteCell(GetID(mouseGridX, mouseGridY))
            end
            PlaceCell(selectedCell, mouseGridX, mouseGridY, selectedRot)
        end
    end
end

function love.load()
    for x = 1, gridX do
        for y = 1, gridY do
            if x == 1 or x == gridX or y == 1 or y == gridY then
                PlaceCell(1, x, y, 0)
            end
        end
    end
end